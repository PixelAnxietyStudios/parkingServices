// Coded by all
#ifndef invoice_h
#define invoice_h

#include <iostream>
#include <string>
using namespace std;

class Invoice
{
  private:
    double price {0.0};
    double discount {0.0};
    double serviceFee {10.0};
    string personString,
           vehicleString;
    
  public:
    Invoice() = default;
    Invoice(double p, double d, double s) : price{p}, discount{d}, serviceFee{s} {}
    void setPrice(double);
    void setDiscount(double);
    void setPersonString(string);
    void setVehicleString(string);
    double getPrice();
    double getDiscount();
    string getPersonString();
    string getVehicleString();
    double calcTotalPrice();
    void outputInvoice();
};

#endif /*invoice_h*/
