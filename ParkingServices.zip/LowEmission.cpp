// Coded by Duncan Hogg

#include "LowEmission.h"
#include <string>
#include <iomanip>
using namespace std;

LowEmission::LowEmission(char e, double m)
{
    setElectric(e);
    setMiles(m);
}

void LowEmission::setElectric(char e)
{
    if (e == 'y' || e == 'n')
        { electric = true;}
}

void LowEmission::setMiles(double m)
{
    if (m > 0)
        { miles = m;}
}

// returns a string containing all the nformation provided  by the user with labels
// pass this into invoice to print it
string LowEmission::lowEmissionInfo(){
  string temp = to_string(miles);
  temp = temp.substr(0, temp.find(".")+3);  // converts miles to a string, then shortens to only include 2 decimal places
  string info = "Make: ";
  info.append(make);
  info += "\nModel: ";
  info.append(model);
  info += "\nYear: ";
  info.append(to_string(year));
  switch (electric){
    case true:
      info += "\nElectric Vehicle: yes";
      break;
    case false:
      info += "\nElectric Vehicle: no";
  }
   info += "\nMiles per gallon (or equivalent): ";
   info.append(temp);
  return info;
}