// Coded by Mauricio Fortune
#include "Professor.h"
#include <iostream>
#include <string>
using namespace std;

  void Professor::setName(string tempName)
  {
    name = tempName;
  }
  
  void Professor::setAddress(string tempAddress)
  {
    address = tempAddress;
  }
  
  void Professor::setEmail(string tempEmail)
  {
    email = tempEmail;
  }
  
  void Professor::setSSN(string tempSSN)
  {   
    ssn = tempSSN;
  }
  
  void Professor::setDepartment(string tempDepartment)
  {
    department = tempDepartment;
  }
  
  string Professor::getName()
  {
    return name;
    
  }
  
  string Professor::getAddress()
  {
    return address;
    
  }
  
  string Professor::getEmail()
  {
    return email;
    
  }
  
  string Professor::getSSN()
  {
    return ssn;
   
  }
  
  string Professor::getDepartment()
  {
    return department; 
  }
  
string Professor::professorInfo()
{
  string info = "Name: ";
  info.append(name);
  info += "\nEmail: ";
  info.append(email);
  info += "\nAddress: ";
  info.append(address);
  info += "\nSSN: ";
  info.append(ssn);
  info += "\nDepartment: ";
  info.append(department);
  return info;
}