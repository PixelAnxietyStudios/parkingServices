// Coded by all
#include <iomanip>
#include <iostream>
#include <string>
#include "Invoice.h"
using namespace std;


void Invoice::setPrice(double p) {price = p;}
void Invoice::setDiscount(double d) {discount = d;}
void Invoice::setPersonString(string p) { personString = p;}
void Invoice::setVehicleString(string v) { vehicleString = v;}
double Invoice::getPrice() {return price;}
double Invoice::getDiscount() {return discount;}
string Invoice::getPersonString() {return personString;}
string Invoice::getVehicleString() {return vehicleString;}

double Invoice::calcTotalPrice(){
  
  return (price + serviceFee) * discount;
}

void Invoice::outputInvoice(){

    cout << fixed << setprecision(2) << endl;
    cout << "Personal Information:\n" << personString << endl << endl;
    cout << "Vehicle Information:\n" << vehicleString << endl << endl;
    cout << "\nParking Permit Total: $" << calcTotalPrice() << endl;
}